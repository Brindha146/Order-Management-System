﻿using Microsoft.Extensions.Configuration;
using OrderManagement.Repository;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderManagement.Utility
{
    internal class DbUtil
    {

        private static SqlConnection sqlcon = null;
        private readonly SqlCommand sqlcmd = null;

        public DbUtil()
        {
            //sqlcon = new SqlConnection("Server=LAPTOP-9P3K1IU4\\MSSQLSERVER01;Database=Order Management System;Trusted_Connection=True");
        }

        public List<Product> GetAllProducts()
        {
            List<Product> products = new List<Product>();
            sqlcmd.CommandText = "Select * from Product";
            sqlcmd.Connection = sqlcon;
            sqlcon.Open();
            SqlDataReader reader = sqlcmd.ExecuteReader();
            while (reader.Read())
            {
                Product product = new Product();
                product.ProductId = (int)reader["ProductID"];
                product.ProductName = (String)reader["ProductName"];
                product.Description = (String)reader["Description"];
                product.Price = (Double)reader["Price"];
                product.QuantityInStock = (int)reader["QuantityInStock"];
                product.Type = (String)reader["Type"];
                products.Add(product);
            }
            sqlcon.Close();
            return products;
        }

        //ConnectionEstablished
        private static readonly string connectionString = "Server=LAPTOP-9P3K1IU4\\MSSQLSERVER01;Database=Order Management System;Trusted_Connection=True";
        public static IDbConnection GetDBConn()
        {
            try
            {
                // Create a new SqlConnection object with the connection string
                IDbConnection connection = new SqlConnection(connectionString);

                // Open the database connection
                connection.Open();

                // Return the connection object
                return connection;
            }
            catch (Exception ex)
            {
                // Handle connection errors
                Console.WriteLine($"Error establishing database connection: {ex.Message}");
                throw; 

        }



        /*
        private static IConfiguration _iconfiguration;
        static DbUtil()
        {
            GetAppSettings();
        }

        public static void GetAppSettings()
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).
                AddJsonFile("appsettings.json");
            _iconfiguration = builder.Build();
        }

        public static string GetConnectionString()
        {
            return _iconfiguration.GetConnectionString("LocalConnectionString");
        }
    }*/
}
