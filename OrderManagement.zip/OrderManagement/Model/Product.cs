﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderManagement.Repository
{
    internal class Product
    {
            public int ProductId { get; set; }
            public string ProductName { get; set; }
            public string Description { get; set; }
            public double Price { get; set; }
            public int QuantityInStock { get; set; }
            public string Type { get; set; }

        // Default constructor
        public Product()
            {
            }

            // Parameterized constructor
            public Product(int productId, string productName, string description, double price, int quantityInStock, string type)
            {
                ProductId = productId;
                ProductName = productName;
                Description = description;
                Price = price;
                QuantityInStock = quantityInStock;
                Type = type;
            }

            // Getters and setters
            public int GetProductId()
            {
                return ProductId;
            }

            public void SetProductId(int productId)
            {
                ProductId = productId;
            }

            public string GetProductName()
            {
                return ProductName;
            }

            public void SetProductName(string productName)
            {
                ProductName = productName;
            }

            public string GetDescription()
            {
                return Description;
            }

            public void SetDescription(string description)
            {
                Description = description;
            }

            public double GetPrice()
            {
                return Price;
            }

            public void SetPrice(double price)
            {
                Price = price;
            }

            public int GetQuantityInStock()
            {
                return QuantityInStock;
            }

            public void SetQuantityInStock(int quantityInStock)
            {
                QuantityInStock = quantityInStock;
            }

            public new string GetType()
            {
                return Type;
            }

            public void SetType(string type)
            {
                Type = type;
        }
    }
}
