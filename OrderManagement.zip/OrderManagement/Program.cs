﻿using OrderManagement.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderManagement
{
    internal class Program
    {
        public static void Main(string[] args)
        { 
            bool exitRequested = false;

            while (!exitRequested)
            {
                // Display menu options
                Console.WriteLine("----- Order Management System -----");
                Console.WriteLine("1. Create User");
                Console.WriteLine("2. Create Product");
                Console.WriteLine("3. Create Order");
                Console.WriteLine("4. Cancel Order");
                Console.WriteLine("5. Get All Products");
                Console.WriteLine("6. Get Orders by User");
                Console.WriteLine("7. Exit");
                Console.Write("Enter your choice: ");

                // Read user input
                string choice = Console.ReadLine();

                IOrderManagementRepository orderManagement = new OrderManagement();
                // Use the OrderManagement instance to call the CreateUser method
                User user = new User
                {
                    UserId = 1,
                    Username = "john_doe",
                    Password = "password123",
                    Role = "User"
                };
                Product product = new Product
                {
                    ProductId = 1,
                    ProductName = "Laptop",
                    Description = "High-performance laptop with advanced features",
                    Price = 999.99,
                    QuantityInStock = 10,
                    Type = "Electronics"
                };
                List<Product> products = new List<Product>();
                Product product2 = new Product
                {
                    ProductId = 2,
                    ProductName = "T-shirt",
                    Description = "Comfortable cotton t-shirt",
                    Price = 19.99,
                    QuantityInStock = 50,
                    Type = "Clothing"
                };
                products.Add(product2);

                // Process user choice
                switch (choice)
                {
                    case "1":
                        
                        orderManagement.CreateUser(user);
                        break;
                    case "2":
                        if (user.Role != "Admin")
                        {
                            throw new UnauthorizedAccessException("Only admin users can create products.");
                        }
                        orderManagement.CreateProduct(user, product);
                        Console.WriteLine($"Product '{product.ProductName}' created successfully.");
                        break;
                    case "3":
                        orderManagement.CreateOrder(user, products);
                        break;
                    case "4":
                        orderManagement.CancelOrder(1,1);
                        break;
                    case "5":
                        orderManagement.GetAllProducts();
                        break;
                    case "6":
                        orderManagement.GetOrdersByUser(user);
                        break;
                    case "7":
                        exitRequested = true;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please enter a valid option.");
                        break;
                }

                Console.WriteLine(); // Add a newline for better formatting
            }
        }
    }
}
