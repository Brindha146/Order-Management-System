﻿using System;
using System.Runtime.Serialization;

namespace OrderManagement.Repository
{
    [Serializable]
    internal class OrderNotFoundException : Exception
    {
        public OrderNotFoundException()
        {
        }

        public OrderNotFoundException(string message) : base(message)
        {
        }

        public OrderNotFoundException(string message, Exception innerException) : base(message, innerException)
        {
        }

    }
}