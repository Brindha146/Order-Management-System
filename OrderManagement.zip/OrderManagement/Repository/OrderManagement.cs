﻿using OrderManagement.Exception_Handling;
using OrderManagement.Utility;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderManagement.Repository
{
    public class OrderManagement : IOrderManagementRepository
    {
        void IOrderManagementRepository.CreateOrder(User user, List<Product> products)
        {
            // Create the order
            int orderId = GenerateOrderId();

            // Perform database operations to create the order
            foreach (var product in products)
            {
                //CreateOrder(orderId, user.UserId, product.ProductId);
            }
        }

        private int GenerateOrderId()
        {
            return (int)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
        }

        // Helper method to perform database operations to insert order details
        void IOrderManagementRepository.CreateOrder(int orderId, int userId, int productId)
        {
            try
            {
                // Establish a database connection
                using (SqlConnection connection = (SqlConnection)DbUtil.GetDBConn())
                {
                    // Open the connection
                    connection.Open();

                    // Define the SQL command to insert the order details
                    string insertQuery = "INSERT INTO Orders (OrderID, UserID, ProductID) VALUES (@OrderId, @UserId, @ProductId)";

                    // Create a SqlCommand object
                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        // Add parameters
                        command.Parameters.AddWithValue("@OrderId", orderId);
                        command.Parameters.AddWithValue("@UserId", userId);
                        command.Parameters.AddWithValue("@ProductId", productId);

                        // Execute the SQL command
                        int rowsAffected = command.ExecuteNonQuery();

                        // Check if the insertion was successful
                        if (rowsAffected > 0)
                        {
                            Console.WriteLine($"Order details inserted into database: OrderID={orderId}, UserID={userId}, ProductID={productId}");
                        }
                        else
                        {
                            Console.WriteLine($"Failed to insert order details into database for OrderID={orderId}, UserID={userId}, ProductID={productId}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error creating order: {ex.Message}");
                // You may choose to rethrow the exception here for further handling
                throw;
            }
        }

        void IOrderManagementRepository.CreateProduct(User user, Product product)
        {
            try
            {
                // Check if the user is an admin user
                if (user.Role != "Admin")
                {
                    throw new UnauthorizedAccessException("Only admin users can create products.");
                }

                // Establish a database connection
                using (SqlConnection connection = (SqlConnection)DbUtil.GetDBConn())
                {
                    // Open the connection
                    connection.Open();

                    // Define the SQL command to insert the product details
                    string insertQuery = "INSERT INTO Products (ProductName, Description, Price, QuantityInStock, Type, Brand, WarrantyPeriod) " +
                                         "VALUES (@ProductName, @Description, @Price, @QuantityInStock, @Type, @Brand, @WarrantyPeriod)";

                    // Create a SqlCommand object
                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        // Add parameters
                        command.Parameters.AddWithValue("@ProductName", product.ProductName);
                        command.Parameters.AddWithValue("@Description", product.Description);
                        command.Parameters.AddWithValue("@Price", product.Price);
                        command.Parameters.AddWithValue("@QuantityInStock", product.QuantityInStock);
                        command.Parameters.AddWithValue("@Type", product.Type);
                        command.Parameters.AddWithValue("@Brand", ((Electronics)product).Brand); // Cast to Electronics and access Brand property
                        command.Parameters.AddWithValue("@WarrantyPeriod", ((Electronics)product).WarrantyPeriod); // Cast to Electronics and access WarrantyPeriod property

                        // Execute the SQL command
                        int rowsAffected = command.ExecuteNonQuery();

                        // Check if the insertion was successful
                        if (rowsAffected > 0)
                        {
                            Console.WriteLine($"Product '{product.ProductName}' created successfully.");
                        }
                        else
                        {
                            Console.WriteLine($"Failed to create product '{product.ProductName}'.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error creating product: {ex.Message}");
                // You may choose to rethrow the exception here for further handling
                throw;
            }
        }

        private static void CreateUser1(User user)
        {
            try
            {
                // Establish a database connection
                using (SqlConnection connection = (SqlConnection)DbUtil.GetDBConn())
                {
                    // Open the connection
                    connection.Open();

                    // Define the SQL command to insert the user details
                    string insertQuery = "INSERT INTO Users (Username, Password, Role) VALUES (@Username, @Password, @Role)";

                    // Create a SqlCommand object
                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        // Add parameters
                        command.Parameters.AddWithValue("@Username", user.Username);
                        command.Parameters.AddWithValue("@Password", user.Password);
                        command.Parameters.AddWithValue("@Role", user.Role);

                        // Execute the SQL command
                        int rowsAffected = command.ExecuteNonQuery();

                        // Check if the insertion was successful
                        if (rowsAffected > 0)
                        {
                            Console.WriteLine($"User '{user.Username}' created successfully.");
                        }
                        else
                        {
                            Console.WriteLine($"Failed to create user '{user.Username}'.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error creating user: {ex.Message}");
                // You may choose to rethrow the exception here for further handling
                throw;
            }
        }

        private static List<Product> GetOrdersByUser1(User user)
        {
            List<Product> orders = new List<Product>();

            try
            {
                // Establish a database connection
                using (SqlConnection connection = (SqlConnection)DbUtil.GetDBConn())
                {
                    // Open the connection
                    connection.Open();

                    // Define the SQL query to retrieve orders for the specific user
                    string selectQuery = "SELECT * FROM Orders WHERE UserID = @UserId";

                    // Create a SqlCommand object
                    using (SqlCommand command = new SqlCommand(selectQuery, connection))
                    {
                        // Add parameter for UserID
                        command.Parameters.AddWithValue("@UserId", user.UserId);

                        // Execute the SQL command and read the results
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            // Iterate through the results and add orders to the list
                            while (reader.Read())
                            {
                                Product order = new Product
                                {
                                    // Populate Product properties from the database columns
                                    ProductId = Convert.ToInt32(reader["ProductId"]),
                                    ProductName = Convert.ToString(reader["ProductName"]),
                                    // Add other properties as needed
                                };

                                orders.Add(order);
                            }
                        }
                    }
                }

                Console.WriteLine($"Retrieving orders for user '{user.Username}' from the database.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving orders for user '{user.Username}': {ex.Message}");
                // You may choose to rethrow the exception here for further handling
                throw;
            }

            return orders;
        }

        void IOrderManagementRepository.CancelOrder(int userId, int orderId)
        {
            try
            {
                // Establish database connection
                using (System.Data.IDbConnection connection = DbUtil.GetDBConn())
                {
                    connection.Open();

                    // Check if the order exists
                    string checkOrderQuery = "SELECT COUNT(*) FROM Orders WHERE UserId = @UserId AND OrderId = @OrderId";
                    using (var command = new SqlCommand(checkOrderQuery, (SqlConnection)connection))
                    {
                        command.Parameters.AddWithValue("@UserId", userId);
                        command.Parameters.AddWithValue("@OrderId", orderId);
                        int orderCount = (int)command.ExecuteScalar();

                        if (orderCount == 0)
                        {
                            throw new OrderNotFoundException($"Order with ID {orderId} not found for user with ID {userId}.");
                        }
                    }

                    // Cancel the order
                    string cancelOrderQuery = "DELETE FROM Orders WHERE UserId = @UserId AND OrderId = @OrderId";
                    using (var cancelCommand = new SqlCommand(cancelOrderQuery, (SqlConnection)connection))
                    {
                        cancelCommand.Parameters.AddWithValue("@UserId", userId);
                        cancelCommand.Parameters.AddWithValue("@OrderId", orderId);
                        cancelCommand.ExecuteNonQuery();
                    }

                    Console.WriteLine($"Order with ID {orderId} cancelled successfully for user with ID {userId}.");
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately
                Console.WriteLine($"Error cancelling order: {ex.Message}");
                throw; // Re-throw the exception for higher-level handling
            }
        }

        void IOrderManagementRepository.CreateUser(User user)
        {
            try
            {
                // Establish database connection
                using (var connection = (SqlConnection)DbUtil.GetDBConn())
                {
                    connection.Open();

                    // Insert the user into the database
                    string insertUserQuery = "INSERT INTO Users (UserId, Username, Password, Role) VALUES (@UserId, @Username, @Password, @Role)";
                    using (var command = new SqlCommand(insertUserQuery, connection))
                    {
                        command.Parameters.AddWithValue("@UserId", user.UserId);
                        command.Parameters.AddWithValue("@Username", user.Username);
                        command.Parameters.AddWithValue("@Password", user.Password);
                        command.Parameters.AddWithValue("@Role", user.Role);
                        command.ExecuteNonQuery();
                    }

                    Console.WriteLine($"User '{user.Username}' created successfully.");
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately
                Console.WriteLine($"Error creating user: {ex.Message}");
                throw; // Re-throw the exception for higher-level handling
            }
        }

        List<Product> IOrderManagementRepository.GetAllProducts()
        {
            List<Product> products = new List<Product>();

            try
            {
                // Establish database connection
                using (var connection = (SqlConnection)DbUtil.GetDBConn())
                {
                    connection.Open();

                    // Retrieve all products from the database
                    string getAllProductsQuery = "SELECT * FROM Products";
                    using (var command = new SqlCommand(getAllProductsQuery, connection))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            // Iterate through the result set and map each row to a product object
                            while (reader.Read())
                            {
                                Product product = new Product
                                {
                                    ProductId = Convert.ToInt32(reader["ProductId"]),
                                    ProductName = reader["ProductName"].ToString(),
                                    Description = reader["Description"].ToString(),
                                    Price = Convert.ToDouble(reader["Price"]),
                                    QuantityInStock = Convert.ToInt32(reader["QuantityInStock"]),
                                    Type = reader["Type"].ToString()
                                    // Map other product attributes as needed
                                };

                                products.Add(product);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately
                Console.WriteLine($"Error retrieving products: {ex.Message}");
                throw; // Re-throw the exception for higher-level handling
            }

            return products;
        }

        List<Product> IOrderManagementRepository.GetOrdersByUser(User user)
        {
            List<Product> userOrders = new List<Product>();

            try
            {
                // Establish database connection
                using (var connection = (SqlConnection)DbUtil.GetDBConn())
                {
                    connection.Open();

                    // Retrieve orders for the specified user from the database
                    string getOrdersByUserQuery = "SELECT p.* FROM Products p INNER JOIN Orders o ON p.ProductId = o.ProductId WHERE o.UserId = @UserId";
                    using (var command = new SqlCommand(getOrdersByUserQuery, connection))
                    {
                        command.Parameters.AddWithValue("@UserId", user.UserId);

                        using (var reader = command.ExecuteReader())
                        {
                            // Iterate through the result set and map each row to a product object
                            while (reader.Read())
                            {
                                Product product = new Product
                                {
                                    ProductId = Convert.ToInt32(reader["ProductId"]),
                                    ProductName = reader["ProductName"].ToString(),
                                    Description = reader["Description"].ToString(),
                                    Price = Convert.ToDouble(reader["Price"]),
                                    QuantityInStock = Convert.ToInt32(reader["QuantityInStock"]),
                                    Type = reader["Type"].ToString()
                                    // Map other product attributes as needed
                                };

                                userOrders.Add(product);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately
                Console.WriteLine($"Error retrieving orders for user: {ex.Message}");
                throw; // Re-throw the exception for higher-level handling
            }

            return userOrders;
        }

    }
}
